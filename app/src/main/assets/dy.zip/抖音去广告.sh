
su

cd /data/data/com.ss.android.ugc.aweme/files/
rm -r umeng_general_config.xml
rm -r .umeng
rm -r umeng_message_state.xml
rm -r umeng_it.cache

cd  /data/data/com.ss.android.ugc.aweme/shared_prefs/
rm -r ACCS_BINDumeng:57bfa27c67e58e7d920028d3.xml
rm -r ACCS_SDK.xml
rm -r ACCS_SDK_CHANNEL.xml
rm -r umeng_general_config.xml
rm -r .umeng
rm -r umeng_message_state.xml
rm -r umeng_it.cache
rm -r Agoo_AppStore.xml
rm -r AGOO_BIND.xml
rm -r app_track.xml

cd /data/data/com.ss.android.ugc.aweme/
chmod 551 files
chmod 551 shared_prefs

su

#作者，酷安呼吸沧海