su

cd /data/data/com.ss.android.ugc.aweme/
chmod 771 files
chmod 771 shared_prefs

su

#作者，酷安呼吸沧海