su

cd /data/data/com.ss.android.ugc.aweme/files/
rm -r update_video_data_104822868522

cd /data/data/com.ss.android.ugc.aweme/
chmod 551 files
chmod 551 shared_prefs

su

#作者，酷安呼吸沧海